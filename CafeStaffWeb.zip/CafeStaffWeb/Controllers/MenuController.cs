using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using CafeStaffWeb.Services;
using CafeStaffWeb.Models;

namespace CafeStaffWeb.Controllers
{
    [Authorize]
    public class MenuController : Controller
    {
        private readonly IStaffService _staffService;

        public MenuController(IStaffService staffService)
        {
            _staffService = staffService;
        }

        public async Task<IActionResult> Index()
        {
            var items = await _staffService.GetMenuItems();
            var viewModel = items.Select(m => new MenuItemViewModel
            {
                Id = m.Id,
                Name = m.Name,
                Description = m.Description,
                Price = m.Price,
                Category = m.Category,
                ImageUrl = m.ImageUrl,
                IsAvailable = m.IsAvailable
            }).ToList();
            
            ViewBag.IsManager = User.HasClaim("Position", "Manager");
            return View(viewModel);
        }

        [Authorize(Policy = "ManagerOnly")]
        public IActionResult Create()
        {
            return View();
        }

        [Authorize(Policy = "ManagerOnly")]
        [HttpPost]
        public async Task<IActionResult> Create(MenuItemViewModel model)
        {
            if (ModelState.IsValid)
            {
                var item = new MenuItem
                {
                    Name = model.Name,
                    Description = model.Description,
                    Price = model.Price,
                    Category = model.Category,
                    ImageUrl = null,
                    IsAvailable = true
                };
                await _staffService.AddMenuItem(item);
                return RedirectToAction("Index");
            }
            return View(model);
        }

        [Authorize(Policy = "ManagerOnly")]
        public async Task<IActionResult> Edit(int id)
        {
            var item = await _staffService.GetMenuItemById(id);
            if (item == null) return NotFound();
            
            var viewModel = new MenuItemViewModel
            {
                Id = item.Id,
                Name = item.Name,
                Description = item.Description,
                Price = item.Price,
                Category = item.Category,
                ImageUrl = item.ImageUrl,
                IsAvailable = item.IsAvailable
            };
            return View(viewModel);
        }

        [Authorize(Policy = "ManagerOnly")]
        [HttpPost]
        public async Task<IActionResult> Edit(int id, MenuItemViewModel model)
        {
            if (id != model.Id) return BadRequest();
            
            if (ModelState.IsValid)
            {
                var item = await _staffService.GetMenuItemById(id);
                if (item == null) return NotFound();
                
                item.Name = model.Name;
                item.Description = model.Description;
                item.Price = model.Price;
                item.Category = model.Category;
                
                await _staffService.UpdateMenuItem(item);
                return RedirectToAction("Index");
            }
            return View(model);
        }

        [Authorize(Policy = "ManagerOnly")]
        [HttpPost]
        public async Task<IActionResult> ToggleAvailability(int id)
        {
            var item = await _staffService.GetMenuItemById(id);
            if (item != null)
            {
                await _staffService.UpdateMenuItemAvailability(id, !item.IsAvailable);
            }
            return RedirectToAction("Index");
        }

        [Authorize(Policy = "ManagerOnly")]
        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            var item = await _staffService.GetMenuItemById(id);
            if (item != null)
            {
                await _staffService.DeleteMenuItem(id);
            }
            return RedirectToAction("Index");
        }
    }
}