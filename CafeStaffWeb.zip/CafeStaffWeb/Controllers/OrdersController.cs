using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using CafeStaffWeb.Services;
using CafeStaffWeb.Models;

namespace CafeStaffWeb.Controllers
{
    [Authorize]
    public class OrdersController : Controller
    {
        private readonly IStaffService _staffService;

        public OrdersController(IStaffService staffService)
        {
            _staffService = staffService;
        }

        public async Task<IActionResult> Index()
        {
            var orders = await _staffService.GetOrders();
            var viewModel = orders.Select(o => new OrderViewModel
            {
                Id = o.Id,
                OrderNumber = o.OrderNumber,
                CustomerName = o.User?.FullName ?? "Гость",
                CustomerEmail = o.User?.Email ?? "",
                CustomerPhone = o.User?.Phone ?? "",
                TotalAmount = o.TotalAmount,
                Status = o.Status,
                OrderType = o.OrderType,
                DeliveryAddress = o.DeliveryAddress,
                DeliveryPhone = o.DeliveryPhone,
                Notes = o.Notes,
                CreatedAt = o.CreatedAt,
                Items = o.OrderItems?.Select(oi => new OrderItemViewModel
                {
                    Name = oi.MenuItem?.Name ?? "",
                    Quantity = oi.Quantity,
                    Price = oi.Price,
                    Subtotal = oi.Quantity * oi.Price,
                    Notes = oi.Notes
                }).ToList() ?? new List<OrderItemViewModel>()
            }).ToList();
            
            ViewBag.IsManager = User.HasClaim("Position", "Manager");
            return View(viewModel);
        }

        public async Task<IActionResult> Details(int id)
        {
            var order = await _staffService.GetOrderById(id);
            if (order == null) return NotFound();

            var viewModel = new OrderViewModel
            {
                Id = order.Id,
                OrderNumber = order.OrderNumber,
                CustomerName = order.User?.FullName ?? "Гость",
                CustomerEmail = order.User?.Email ?? "",
                CustomerPhone = order.User?.Phone ?? "",
                TotalAmount = order.TotalAmount,
                Status = order.Status,
                OrderType = order.OrderType,
                DeliveryAddress = order.DeliveryAddress,
                DeliveryPhone = order.DeliveryPhone,
                Notes = order.Notes,
                CreatedAt = order.CreatedAt,
                Items = order.OrderItems?.Select(oi => new OrderItemViewModel
                {
                    Name = oi.MenuItem?.Name ?? "",
                    Quantity = oi.Quantity,
                    Price = oi.Price,
                    Subtotal = oi.Quantity * oi.Price,
                    Notes = oi.Notes
                }).ToList() ?? new List<OrderItemViewModel>()
            };
            
            ViewBag.IsManager = User.HasClaim("Position", "Manager");
            return View(viewModel);
        }

        [HttpPost]
        [Authorize(Policy = "ManagerOnly")]
        public async Task<IActionResult> UpdateStatus(int id, string status)
        {
            await _staffService.UpdateOrderStatus(id, status);
            return RedirectToAction("Index");
        }
    }
}