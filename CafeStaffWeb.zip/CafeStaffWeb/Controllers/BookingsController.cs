using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using CafeStaffWeb.Services;
using CafeStaffWeb.Models;

namespace CafeStaffWeb.Controllers
{
    [Authorize]
    public class BookingsController : Controller
    {
        private readonly IStaffService _staffService;

        public BookingsController(IStaffService staffService)
        {
            _staffService = staffService;
        }

        public async Task<IActionResult> Index()
        {
            var bookings = await _staffService.GetBookings();
            var viewModel = bookings.Select(b => new BookingViewModel
            {
                Id = b.Id,
                CustomerName = b.User?.FullName ?? "Гость",
                CustomerEmail = b.User?.Email ?? "",
                CustomerPhone = b.User?.Phone ?? "",
                TableId = b.TableId,
                TableNumber = b.Table?.TableNumber ?? 0,
                BookingDate = b.BookingDate,
                BookingTime = b.BookingTime,
                GuestsCount = b.GuestsCount,
                Status = b.Status,
                CreatedAt = b.CreatedAt
            }).ToList();
            
            ViewBag.IsManager = User.HasClaim("Position", "Manager");
            return View(viewModel);
        }

        [HttpPost]
        [Authorize(Policy = "ManagerOnly")]
        public async Task<IActionResult> Confirm(int id)
        {
            await _staffService.ConfirmBooking(id);
            return RedirectToAction("Index");
        }

        [HttpPost]
        [Authorize(Policy = "ManagerOnly")]
        public async Task<IActionResult> Cancel(int id)
        {
            await _staffService.CancelBooking(id);
            return RedirectToAction("Index");
        }
    }
}