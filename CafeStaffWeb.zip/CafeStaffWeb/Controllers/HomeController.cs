using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using CafeStaffWeb.Services;

namespace CafeStaffWeb.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly IStaffService _staffService;

        public HomeController(IStaffService staffService)
        {
            _staffService = staffService;
        }

        public async Task<IActionResult> Index()
        {
            var dashboard = await _staffService.GetDashboardData();
            ViewBag.IsManager = await _staffService.IsManager(User.Identity?.Name ?? "");
            return View(dashboard);
        }
    }
}