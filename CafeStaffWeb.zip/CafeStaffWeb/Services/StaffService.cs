using Microsoft.EntityFrameworkCore;
using CafeStaffWeb.Data;
using CafeStaffWeb.Models;
using System.Security.Cryptography;
using System.Text;

namespace CafeStaffWeb.Services
{
    public interface IStaffService
    {
        Task<User?> Authenticate(string email, string password);
        Task<User?> GetUserByEmail(string email);
        Task<List<Booking>> GetBookings();
        Task<Booking?> GetBookingById(int id);
        Task<bool> ConfirmBooking(int id);
        Task<bool> CancelBooking(int id);
        Task<List<Order>> GetOrders();
        Task<Order?> GetOrderById(int id);
        Task<bool> UpdateOrderStatus(int id, string status);
        Task<List<MenuItem>> GetMenuItems();
        Task<MenuItem?> GetMenuItemById(int id);
        Task<bool> UpdateMenuItemAvailability(int id, bool isAvailable);
        Task<bool> AddMenuItem(MenuItem item);
        Task<bool> UpdateMenuItem(MenuItem item);  // <-- ДОБАВЬТЕ ЭТУ СТРОКУ
        Task<bool> DeleteMenuItem(int id);
        Task<DashboardViewModel> GetDashboardData();
        Task<bool> IsManager(string email);
    }

    public class StaffService : IStaffService
    {
        private readonly StaffDbContext _context;

        public StaffService(StaffDbContext context)
        {
            _context = context;
        }

        private string HashPassword(string password)
        {
            using var sha256 = SHA256.Create();
            var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
            return Convert.ToBase64String(hashedBytes);
        }

        private bool VerifyPassword(string password, string hash)
        {
            return HashPassword(password) == hash;
        }

        public async Task<User?> Authenticate(string email, string password)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Email == email && u.IsActive && (u.Position == "Manager" || u.Position == "Waiter"));
            
            if (user == null) return null;
            return VerifyPassword(password, user.PasswordHash) ? user : null;
        }

        public async Task<User?> GetUserByEmail(string email)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
        }

        public async Task<bool> IsManager(string email)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
            return user?.Position == "Manager";
        }

        public async Task<List<Booking>> GetBookings()
        {
            return await _context.Bookings
                .Include(b => b.User)
                .Include(b => b.Table)
                .OrderByDescending(b => b.BookingDate)
                .ThenBy(b => b.BookingTime)
                .ToListAsync();
        }

        public async Task<Booking?> GetBookingById(int id)
        {
            return await _context.Bookings
                .Include(b => b.User)
                .Include(b => b.Table)
                .FirstOrDefaultAsync(b => b.Id == id);
        }

        public async Task<bool> ConfirmBooking(int id)
        {
            var booking = await _context.Bookings.FindAsync(id);
            if (booking != null && booking.Status == "Pending")
            {
                booking.Status = "Confirmed";
                await _context.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<bool> CancelBooking(int id)
        {
            var booking = await _context.Bookings.FindAsync(id);
            if (booking != null && booking.Status != "Cancelled")
            {
                booking.Status = "Cancelled";
                await _context.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<List<Order>> GetOrders()
        {
            return await _context.Orders
                .Include(o => o.User)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.MenuItem)
                .OrderByDescending(o => o.CreatedAt)
                .ToListAsync();
        }

        public async Task<Order?> GetOrderById(int id)
        {
            return await _context.Orders
                .Include(o => o.User)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.MenuItem)
                .FirstOrDefaultAsync(o => o.Id == id);
        }

        public async Task<bool> UpdateOrderStatus(int id, string status)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order != null)
            {
                order.Status = status;
                await _context.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<List<MenuItem>> GetMenuItems()
        {
            return await _context.MenuItems.OrderBy(m => m.Category).ThenBy(m => m.Name).ToListAsync();
        }

        public async Task<MenuItem?> GetMenuItemById(int id)
        {
            return await _context.MenuItems.FindAsync(id);
        }

        public async Task<bool> UpdateMenuItemAvailability(int id, bool isAvailable)
        {
            var item = await _context.MenuItems.FindAsync(id);
            if (item != null)
            {
                item.IsAvailable = isAvailable;
                await _context.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<bool> AddMenuItem(MenuItem item)
        {
            _context.MenuItems.Add(item);
            await _context.SaveChangesAsync();
            return true;
        }

        // ДОБАВЬТЕ ЭТОТ МЕТОД:
        public async Task<bool> UpdateMenuItem(MenuItem item)
        {
            _context.MenuItems.Update(item);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteMenuItem(int id)
        {
            var item = await _context.MenuItems.FindAsync(id);
            if (item != null)
            {
                _context.MenuItems.Remove(item);
                await _context.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<DashboardViewModel> GetDashboardData()
        {
            var today = DateTime.UtcNow.Date;
            var orders = await _context.Orders.ToListAsync();
            var bookings = await _context.Bookings.ToListAsync();
            var menuItems = await _context.MenuItems.ToListAsync();

            var recentOrders = await GetOrders();
            var recentBookings = await GetBookings();

            return new DashboardViewModel
            {
                TotalOrders = orders.Count,
                PendingOrders = orders.Count(o => o.Status == "Pending"),
                TotalBookings = bookings.Count,
                PendingBookings = bookings.Count(b => b.Status == "Pending"),
                TotalUsers = await _context.Users.CountAsync(u => u.IsActive),
                TotalMenuItems = menuItems.Count,
                AvailableMenuItems = menuItems.Count(m => m.IsAvailable),
                TodayRevenue = orders.Where(o => o.CreatedAt.Date == today && o.Status != "Cancelled").Sum(o => o.TotalAmount),
                RecentOrders = recentOrders.Take(5).Select(o => new OrderViewModel
                {
                    Id = o.Id,
                    OrderNumber = o.OrderNumber,
                    CustomerName = o.User?.FullName ?? "Гость",
                    TotalAmount = o.TotalAmount,
                    Status = o.Status,
                    OrderType = o.OrderType,
                    CreatedAt = o.CreatedAt
                }).ToList(),
                RecentBookings = recentBookings.Take(5).Select(b => new BookingViewModel
                {
                    Id = b.Id,
                    CustomerName = b.User?.FullName ?? "Гость",
                    TableNumber = b.Table?.TableNumber ?? 0,
                    BookingDate = b.BookingDate,
                    BookingTime = b.BookingTime,
                    GuestsCount = b.GuestsCount,
                    Status = b.Status
                }).ToList()
            };
        }
    }
}