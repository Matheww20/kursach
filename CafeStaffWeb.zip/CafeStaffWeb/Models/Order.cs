using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CafeStaffWeb.Models
{
    public class Order
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        public int UserId { get; set; }
        
        [Required, MaxLength(50)]
        public string OrderNumber { get; set; } = string.Empty;
        
        [Required]
        public decimal TotalAmount { get; set; }
        
        [MaxLength(20)]
        public string Status { get; set; } = "Pending";
        
        [MaxLength(20)]
        public string OrderType { get; set; } = "DineIn";
        
        [MaxLength(500)]
        public string? DeliveryAddress { get; set; }
        
        [MaxLength(20)]
        public string? DeliveryPhone { get; set; }
        
        [MaxLength(500)]
        public string? Notes { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        
        [ForeignKey("UserId")]
        public virtual User? User { get; set; }
        
        public virtual ICollection<OrderItem>? OrderItems { get; set; }
    }
}