﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CafeRestAPI.Models;
using CafeRestAPI.Models.Responses;

namespace CafeRestAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TablesController : ControllerBase
    {
        private readonly DbContextSalon _context;

        public TablesController(DbContextSalon context)
        {
            _context = context;
        }

        /// <summary>
        /// Получить все столы
        /// </summary>
        [HttpGet]
        [AllowAnonymous]
        [ProducesResponseType(typeof(ApiResponse<List<Table>>), 200)]
        public async Task<IActionResult> GetAllTables()
        {
            var tables = await _context.Tables.ToListAsync();
            return Ok(ApiResponse<List<Table>>.Ok(tables));
        }

        /// <summary>
        /// Получить стол по ID
        /// </summary>
        [HttpGet("{id}")]
        [AllowAnonymous]
        [ProducesResponseType(typeof(ApiResponse<Table>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 404)]
        public async Task<IActionResult> GetTableById(int id)
        {
            var table = await _context.Tables.FindAsync(id);

            if (table == null)
                return NotFound(ApiResponse<object>.Fail("Стол не найден"));

            return Ok(ApiResponse<Table>.Ok(table));
        }
    }
}