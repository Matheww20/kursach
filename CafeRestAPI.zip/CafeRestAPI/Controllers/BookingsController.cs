﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using CafeRestAPI.Models;
using CafeRestAPI.Models.DTOs;
using CafeRestAPI.Models.Responses;

namespace CafeRestAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingsController : ControllerBase
    {
        private readonly DbContextSalon _context;

        public BookingsController(DbContextSalon context)
        {
            _context = context;
        }

        private int GetUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
            if (userIdClaim == null) return 0;
            return int.Parse(userIdClaim.Value);
        }

        // GET: api/Bookings - получить все бронирования пользователя
        [Authorize]
        [HttpGet]
        public async Task<IActionResult> GetUserBookings()
        {
            var userId = GetUserId();
            var bookings = await _context.Bookings
                .Include(b => b.Table)
                .Where(b => b.UserId == userId)
                .OrderByDescending(b => b.BookingDate)
                .ThenBy(b => b.BookingTime)
                .Select(b => new
                {
                    b.Id,
                    b.TableId,
                    TableNumber = b.Table != null ? b.Table.TableNumber : 0,
                    b.BookingDate,
                    b.BookingTime,
                    b.GuestsCount,
                    b.Status,
                    b.CreatedAt
                })
                .ToListAsync();

            return Ok(ApiResponse<object>.Ok(bookings));
        }

        // GET: api/Bookings/available?date=...&time=...&guests=...
        [AllowAnonymous]
        [HttpGet("available")]
        public async Task<IActionResult> GetAvailableTables(
            [FromQuery] DateTime date,
            [FromQuery] TimeSpan time,
            [FromQuery] int guests)
        {
            // Находим забронированные столы
            var bookedTableIds = await _context.Bookings
                .Where(b => b.BookingDate.Date == date.Date &&
                            b.BookingTime == time &&
                            b.Status != "Cancelled")
                .Select(b => b.TableId)
                .ToListAsync();

            // Находим доступные столы
            var availableTables = await _context.Tables
                .Where(t => t.Capacity >= guests && !bookedTableIds.Contains(t.Id))
                .Select(t => new
                {
                    t.Id,
                    t.TableNumber,
                    t.Capacity,
                    t.IsAvailable
                })
                .ToListAsync();

            return Ok(ApiResponse<object>.Ok(availableTables));
        }

        // POST: api/Bookings - создать бронирование
        [Authorize]
        [HttpPost]
        public async Task<IActionResult> CreateBooking([FromBody] CreateBookingDto dto)
        {
            var userId = GetUserId();

            // Проверяем существование стола
            var table = await _context.Tables.FindAsync(dto.TableId);
            if (table == null)
                return BadRequest(ApiResponse<object>.Fail("Стол не найден"));

            // Проверяем вместимость
            if (table.Capacity < dto.GuestsCount)
                return BadRequest(ApiResponse<object>.Fail("Стол не вмещает указанное количество гостей"));

            // Проверяем, свободен ли стол
            var existingBooking = await _context.Bookings
                .FirstOrDefaultAsync(b => b.TableId == dto.TableId &&
                    b.BookingDate.Date == dto.BookingDate.Date &&
                    b.BookingTime == dto.BookingTime &&
                    b.Status != "Cancelled");

            if (existingBooking != null)
                return BadRequest(ApiResponse<object>.Fail("Стол уже забронирован на это время"));

            // Создаем бронирование
            var booking = new Booking
            {
                UserId = userId,
                TableId = dto.TableId,
                BookingDate = dto.BookingDate.Date,
                BookingTime = dto.BookingTime,
                GuestsCount = dto.GuestsCount,
                Status = "Pending",
                CreatedAt = DateTime.UtcNow
            };

            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();

            return Ok(ApiResponse<object>.Ok(new
            {
                booking.Id,
                booking.TableId,
                TableNumber = table.TableNumber,
                booking.BookingDate,
                booking.BookingTime,
                booking.GuestsCount,
                booking.Status,
                booking.CreatedAt
            }, "Бронирование успешно создано"));
        }

        // DELETE: api/Bookings/{id} - отменить бронирование
        [Authorize]
        [HttpDelete("{id}")]
        public async Task<IActionResult> CancelBooking(int id)
        {
            var userId = GetUserId();
            var booking = await _context.Bookings
                .FirstOrDefaultAsync(b => b.Id == id && b.UserId == userId);

            if (booking == null)
                return NotFound(ApiResponse<object>.Fail("Бронирование не найдено"));

            if (booking.Status == "Cancelled")
                return BadRequest(ApiResponse<object>.Fail("Бронирование уже отменено"));

            booking.Status = "Cancelled";
            await _context.SaveChangesAsync();

            return Ok(ApiResponse<object>.Ok(null, "Бронирование отменено"));
        }
    }
}