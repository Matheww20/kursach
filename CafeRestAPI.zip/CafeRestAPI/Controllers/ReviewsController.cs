﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using CafeRestAPI.Models;
using CafeRestAPI.Models.DTOs;
using CafeRestAPI.Models.Responses;

namespace CafeRestAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReviewsController : ControllerBase
    {
        private readonly DbContextSalon _context;

        public ReviewsController(DbContextSalon context)
        {
            _context = context;
        }

        private int GetUserId()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return userId != null ? int.Parse(userId) : 0;
        }

        /// <summary>
        /// Получить все отзывы
        /// </summary>
        [HttpGet]
        [AllowAnonymous]
        [ProducesResponseType(typeof(ApiResponse<List<ReviewResponseDto>>), 200)]
        public async Task<IActionResult> GetReviews()
        {
            var reviews = await _context.Reviews
                .Include(r => r.User)
                .OrderByDescending(r => r.CreatedAt)
                .Select(r => new ReviewResponseDto
                {
                    Id = r.Id,
                    UserName = r.User != null ? r.User.FullName : "Аноним",
                    Rating = r.Rating,
                    Comment = r.Comment,
                    CreatedAt = r.CreatedAt
                })
                .ToListAsync();

            return Ok(ApiResponse<List<ReviewResponseDto>>.Ok(reviews));
        }

        /// <summary>
        /// Создать отзыв
        /// </summary>
        [Authorize]
        [HttpPost]
        [ProducesResponseType(typeof(ApiResponse<object>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 400)]
        public async Task<IActionResult> CreateReview([FromBody] CreateReviewDto dto)
        {
            var review = new Review
            {
                UserId = GetUserId(),
                OrderId = dto.OrderId,
                Rating = dto.Rating,
                Comment = dto.Comment,
                CreatedAt = DateTime.UtcNow
            };

            _context.Reviews.Add(review);
            await _context.SaveChangesAsync();

            return Ok(ApiResponse<object>.Ok(null, "Отзыв успешно добавлен"));
        }

        /// <summary>
        /// Удалить отзыв
        /// </summary>
        [Authorize]
        [HttpDelete("{id}")]
        [ProducesResponseType(typeof(ApiResponse<object>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 404)]
        public async Task<IActionResult> DeleteReview(int id)
        {
            var review = await _context.Reviews.FindAsync(id);

            if (review == null)
                return NotFound(ApiResponse<object>.Fail("Отзыв не найден"));

            var userId = GetUserId();
            if (review.UserId != userId)
                return Forbid();

            _context.Reviews.Remove(review);
            await _context.SaveChangesAsync();

            return Ok(ApiResponse<object>.Ok(null, "Отзыв удален"));
        }
    }
}