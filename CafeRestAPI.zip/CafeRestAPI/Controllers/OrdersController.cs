﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using CafeRestAPI.Models.DTOs;
using CafeRestAPI.Models.Responses;
using CafeRestAPI.Services;

namespace CafeRestAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderService _orderService;

        public OrdersController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        private int GetUserId()
        {
            return int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
        }

        /// <summary>
        /// Создать заказ из корзины
        /// </summary>
        [HttpPost]
        [ProducesResponseType(typeof(ApiResponse<OrderResponseDto>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 400)]
        public async Task<IActionResult> CreateOrder([FromBody] CreateOrderDto dto)
        {
            var order = await _orderService.CreateOrderAsync(GetUserId(), dto);

            if (order == null)
                return BadRequest(ApiResponse<object>.Fail("Корзина пуста или ошибка создания заказа"));

            return Ok(ApiResponse<OrderResponseDto>.Ok(order, "Заказ успешно создан"));
        }

        /// <summary>
        /// Получить все заказы пользователя
        /// </summary>
        [HttpGet]
        [ProducesResponseType(typeof(ApiResponse<List<OrderResponseDto>>), 200)]
        public async Task<IActionResult> GetOrders()
        {
            var orders = await _orderService.GetUserOrdersAsync(GetUserId());
            return Ok(ApiResponse<List<OrderResponseDto>>.Ok(orders));
        }

        /// <summary>
        /// Получить заказ по ID
        /// </summary>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(ApiResponse<OrderResponseDto>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 404)]
        public async Task<IActionResult> GetOrder(int id)
        {
            var order = await _orderService.GetOrderByIdAsync(GetUserId(), id);

            if (order == null)
                return NotFound(ApiResponse<object>.Fail("Заказ не найден"));

            return Ok(ApiResponse<OrderResponseDto>.Ok(order));
        }

        /// <summary>
        /// Отменить заказ
        /// </summary>
        [HttpPut("{id}/cancel")]
        [ProducesResponseType(typeof(ApiResponse<object>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 404)]
        public async Task<IActionResult> CancelOrder(int id)
        {
            var result = await _orderService.CancelOrderAsync(GetUserId(), id);

            if (!result)
                return NotFound(ApiResponse<object>.Fail("Заказ не найден или уже отменен"));

            return Ok(ApiResponse<object>.Ok(null, "Заказ отменен"));
        }
    }
}