﻿using Microsoft.AspNetCore.Mvc;
using CafeRestAPI.Models.DTOs;
using CafeRestAPI.Models.Responses;
using CafeRestAPI.Services;

namespace CafeRestAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        /// <summary>
        /// Регистрация нового пользователя
        /// </summary>
        [HttpPost("register")]
        [ProducesResponseType(typeof(ApiResponse<AuthResponseDto>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 400)]
        public async Task<IActionResult> Register([FromBody] RegisterDto registerDto)
        {
            var result = await _authService.RegisterAsync(registerDto);

            if (result == null)
                return BadRequest(ApiResponse<object>.Fail("Пользователь с таким email уже существует"));

            return Ok(ApiResponse<AuthResponseDto>.Ok(result, "Регистрация успешна"));
        }

        /// <summary>
        /// Вход в систему
        /// </summary>
        [HttpPost("login")]
        [ProducesResponseType(typeof(ApiResponse<AuthResponseDto>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 401)]
        public async Task<IActionResult> Login([FromBody] LoginDto loginDto)
        {
            var result = await _authService.LoginAsync(loginDto);

            if (result == null)
                return Unauthorized(ApiResponse<object>.Fail("Неверный email или пароль"));

            return Ok(ApiResponse<AuthResponseDto>.Ok(result, "Вход выполнен успешно"));
        }
    }
}