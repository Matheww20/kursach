﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CafeRestAPI.Models;
using CafeRestAPI.Models.DTOs;
using CafeRestAPI.Models.Responses;

namespace CafeRestAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MenuController : ControllerBase
    {
        private readonly DbContextSalon _context;

        public MenuController(DbContextSalon context)
        {
            _context = context;
        }

        /// <summary>
        /// Получить всё меню
        /// </summary>
        [HttpGet]
        [ProducesResponseType(typeof(ApiResponse<List<MenuItemDto>>), 200)]
        public async Task<IActionResult> GetMenu([FromQuery] string? category = null)
        {
            var query = _context.MenuItems
                .Where(m => m.IsAvailable)
                .AsQueryable();

            if (!string.IsNullOrEmpty(category))
                query = query.Where(m => m.Category == category);

            var menu = await query
                .Select(m => new MenuItemDto
                {
                    Id = m.Id,
                    Name = m.Name,
                    Description = m.Description,
                    Price = m.Price,
                    Category = m.Category,
                    ImageUrl = m.ImageUrl,
                    IsAvailable = m.IsAvailable
                })
                .ToListAsync();

            return Ok(ApiResponse<List<MenuItemDto>>.Ok(menu));
        }

        /// <summary>
        /// Получить блюдо по ID
        /// </summary>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(ApiResponse<MenuItemDto>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 404)]
        public async Task<IActionResult> GetMenuItem(int id)
        {
            var item = await _context.MenuItems
                .Where(m => m.Id == id && m.IsAvailable)
                .Select(m => new MenuItemDto
                {
                    Id = m.Id,
                    Name = m.Name,
                    Description = m.Description,
                    Price = m.Price,
                    Category = m.Category,
                    ImageUrl = m.ImageUrl,
                    IsAvailable = m.IsAvailable
                })
                .FirstOrDefaultAsync();

            if (item == null)
                return NotFound(ApiResponse<object>.Fail("Блюдо не найдено"));

            return Ok(ApiResponse<MenuItemDto>.Ok(item));
        }

        /// <summary>
        /// Получить все категории меню
        /// </summary>
        [HttpGet("categories")]
        [ProducesResponseType(typeof(ApiResponse<List<string>>), 200)]
        public async Task<IActionResult> GetCategories()
        {
            var categories = await _context.MenuItems
                .Where(m => m.IsAvailable)
                .Select(m => m.Category)
                .Distinct()
                .ToListAsync();

            return Ok(ApiResponse<List<string>>.Ok(categories));
        }
    }
}