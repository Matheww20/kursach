﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using CafeRestAPI.Models;
using CafeRestAPI.Models.DTOs;
using CafeRestAPI.Models.Responses;
using CafeRestAPI.Helpers;

namespace CafeRestAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ProfileController : ControllerBase
    {
        private readonly DbContextSalon _context;

        public ProfileController(DbContextSalon context)
        {
            _context = context;
        }

        private int GetUserId()
        {
            return int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
        }

        /// <summary>
        /// Получить профиль пользователя
        /// </summary>
        [HttpGet]
        [ProducesResponseType(typeof(ApiResponse<object>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 404)]
        public async Task<IActionResult> GetProfile()
        {
            var user = await _context.Users
                .Where(u => u.Id == GetUserId())
                .Select(u => new
                {
                    u.Id,
                    u.Email,
                    u.FullName,
                    u.Phone,
                    u.Address,
                    u.CreatedAt
                })
                .FirstOrDefaultAsync();

            if (user == null)
                return NotFound(ApiResponse<object>.Fail("Пользователь не найден"));

            return Ok(ApiResponse<object>.Ok(user));
        }

        /// <summary>
        /// Обновить профиль пользователя
        /// </summary>
        [HttpPut]
        [ProducesResponseType(typeof(ApiResponse<object>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 404)]
        public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileDto dto)
        {
            var user = await _context.Users.FindAsync(GetUserId());

            if (user == null)
                return NotFound(ApiResponse<object>.Fail("Пользователь не найден"));

            if (!string.IsNullOrEmpty(dto.FullName))
                user.FullName = dto.FullName;

            if (!string.IsNullOrEmpty(dto.Phone))
                user.Phone = dto.Phone;

            if (!string.IsNullOrEmpty(dto.Address))
                user.Address = dto.Address;

            await _context.SaveChangesAsync();

            return Ok(ApiResponse<object>.Ok(null, "Профиль обновлен"));
        }

        /// <summary>
        /// Изменить пароль
        /// </summary>
        [HttpPut("change-password")]
        [ProducesResponseType(typeof(ApiResponse<object>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 400)]
        public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordDto dto)
        {
            var user = await _context.Users.FindAsync(GetUserId());

            if (user == null)
                return NotFound(ApiResponse<object>.Fail("Пользователь не найден"));

            if (!PasswordHasher.VerifyPassword(dto.CurrentPassword, user.PasswordHash))
                return BadRequest(ApiResponse<object>.Fail("Текущий пароль неверен"));

            user.PasswordHash = PasswordHasher.HashPassword(dto.NewPassword);
            await _context.SaveChangesAsync();

            return Ok(ApiResponse<object>.Ok(null, "Пароль успешно изменен"));
        }
    }
}