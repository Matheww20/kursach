﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using CafeRestAPI.Models.DTOs;
using CafeRestAPI.Models.Responses;
using CafeRestAPI.Services;

namespace CafeRestAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly ICartService _cartService;

        public CartController(ICartService cartService)
        {
            _cartService = cartService;
        }

        private int GetUserId()
        {
            return int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
        }

        /// <summary>
        /// Получить корзину текущего пользователя
        /// </summary>
        [HttpGet]
        [ProducesResponseType(typeof(ApiResponse<List<CartItemDto>>), 200)]
        public async Task<IActionResult> GetCart()
        {
            var cart = await _cartService.GetCartAsync(GetUserId());
            return Ok(ApiResponse<List<CartItemDto>>.Ok(cart));
        }

        /// <summary>
        /// Добавить товар в корзину
        /// </summary>
        [HttpPost("add")]
        [ProducesResponseType(typeof(ApiResponse<object>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 400)]
        public async Task<IActionResult> AddToCart([FromBody] AddToCartDto dto)
        {
            if (dto.Quantity <= 0)
                return BadRequest(ApiResponse<object>.Fail("Количество должно быть больше 0"));

            var result = await _cartService.AddToCartAsync(GetUserId(), dto);

            if (!result)
                return BadRequest(ApiResponse<object>.Fail("Не удалось добавить товар в корзину"));

            return Ok(ApiResponse<object>.Ok(null, "Товар добавлен в корзину"));
        }

        /// <summary>
        /// Обновить количество товара в корзине
        /// </summary>
        [HttpPut("item/{cartItemId}")]
        [ProducesResponseType(typeof(ApiResponse<object>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 404)]
        public async Task<IActionResult> UpdateCartItem(int cartItemId, [FromBody] int quantity)
        {
            if (quantity < 0)
                return BadRequest(ApiResponse<object>.Fail("Количество не может быть отрицательным"));

            var result = await _cartService.UpdateCartItemAsync(GetUserId(), cartItemId, quantity);

            if (!result)
                return NotFound(ApiResponse<object>.Fail("Товар в корзине не найден"));

            return Ok(ApiResponse<object>.Ok(null, "Корзина обновлена"));
        }

        /// <summary>
        /// Удалить товар из корзины
        /// </summary>
        [HttpDelete("item/{cartItemId}")]
        [ProducesResponseType(typeof(ApiResponse<object>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 404)]
        public async Task<IActionResult> RemoveFromCart(int cartItemId)
        {
            var result = await _cartService.RemoveFromCartAsync(GetUserId(), cartItemId);

            if (!result)
                return NotFound(ApiResponse<object>.Fail("Товар в корзине не найден"));

            return Ok(ApiResponse<object>.Ok(null, "Товар удален из корзины"));
        }

        /// <summary>
        /// Очистить корзину
        /// </summary>
        [HttpDelete("clear")]
        [ProducesResponseType(typeof(ApiResponse<object>), 200)]
        public async Task<IActionResult> ClearCart()
        {
            await _cartService.ClearCartAsync(GetUserId());
            return Ok(ApiResponse<object>.Ok(null, "Корзина очищена"));
        }
    }
}