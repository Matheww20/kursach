﻿using Microsoft.EntityFrameworkCore;
using CafeRestAPI.Models;
using CafeRestAPI.Models.DTOs;

namespace CafeRestAPI.Services
{
    public interface ICartService
    {
        Task<List<CartItemDto>> GetCartAsync(int userId);
        Task<bool> AddToCartAsync(int userId, AddToCartDto dto);
        Task<bool> UpdateCartItemAsync(int userId, int cartItemId, int quantity);
        Task<bool> RemoveFromCartAsync(int userId, int cartItemId);
        Task<bool> ClearCartAsync(int userId);
    }

    public class CartService : ICartService
    {
        private readonly DbContextSalon _context;

        public CartService(DbContextSalon context)
        {
            _context = context;
        }

        public async Task<List<CartItemDto>> GetCartAsync(int userId)
        {
            var cart = await _context.Carts
                .Include(c => c.CartItems)
                    .ThenInclude(ci => ci.MenuItem)
                .FirstOrDefaultAsync(c => c.UserId == userId);

            if (cart == null) return new List<CartItemDto>();

            return cart.CartItems.Select(ci => new CartItemDto
            {
                Id = ci.Id,
                MenuItemId = ci.MenuItemId,
                Name = ci.MenuItem?.Name ?? string.Empty,
                Price = ci.MenuItem?.Price ?? 0,
                Quantity = ci.Quantity,
                Subtotal = (ci.MenuItem?.Price ?? 0) * ci.Quantity,
                Notes = ci.Notes
            }).ToList();
        }

        public async Task<bool> AddToCartAsync(int userId, AddToCartDto dto)
        {
            var cart = await _context.Carts
                .Include(c => c.CartItems)
                .FirstOrDefaultAsync(c => c.UserId == userId);

            if (cart == null)
            {
                cart = new Cart { UserId = userId };
                _context.Carts.Add(cart);
                await _context.SaveChangesAsync();
            }

            var existingItem = cart.CartItems.FirstOrDefault(ci => ci.MenuItemId == dto.MenuItemId);

            if (existingItem != null)
            {
                existingItem.Quantity += dto.Quantity;
            }
            else
            {
                cart.CartItems.Add(new CartItem
                {
                    MenuItemId = dto.MenuItemId,
                    Quantity = dto.Quantity,
                    Notes = dto.Notes
                });
            }

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateCartItemAsync(int userId, int cartItemId, int quantity)
        {
            var cartItem = await _context.CartItems
                .Include(ci => ci.Cart)
                .FirstOrDefaultAsync(ci => ci.Id == cartItemId && ci.Cart.UserId == userId);

            if (cartItem == null) return false;

            if (quantity <= 0)
            {
                _context.CartItems.Remove(cartItem);
            }
            else
            {
                cartItem.Quantity = quantity;
            }

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> RemoveFromCartAsync(int userId, int cartItemId)
        {
            var cartItem = await _context.CartItems
                .Include(ci => ci.Cart)
                .FirstOrDefaultAsync(ci => ci.Id == cartItemId && ci.Cart.UserId == userId);

            if (cartItem == null) return false;

            _context.CartItems.Remove(cartItem);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> ClearCartAsync(int userId)
        {
            var cart = await _context.Carts
                .Include(c => c.CartItems)
                .FirstOrDefaultAsync(c => c.UserId == userId);

            if (cart == null) return true;

            _context.CartItems.RemoveRange(cart.CartItems);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}