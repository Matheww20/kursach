﻿using Microsoft.EntityFrameworkCore;
using CafeRestAPI.Models;
using CafeRestAPI.Models.DTOs;

namespace CafeRestAPI.Services
{
    public interface IBookingService
    {
        Task<BookingResponseDto?> CreateBookingAsync(int userId, CreateBookingDto dto);
        Task<List<BookingResponseDto>> GetUserBookingsAsync(int userId);
        Task<bool> CancelBookingAsync(int userId, int bookingId);
        Task<List<Table>> GetAvailableTablesAsync(DateTime date, TimeSpan time, int guests);
    }

    public class BookingService : IBookingService
    {
        private readonly DbContextSalon _context;

        public BookingService(DbContextSalon context)
        {
            _context = context;
        }

        public async Task<BookingResponseDto?> CreateBookingAsync(int userId, CreateBookingDto dto)
        {
            // Проверяем существование стола
            var table = await _context.Tables.FindAsync(dto.TableId);
            if (table == null)
                return null;

            // Проверяем вместимость стола
            if (table.Capacity < dto.GuestsCount)
                return null;

            // Проверяем, свободен ли стол в указанное время
            var existingBooking = await _context.Bookings
                .FirstOrDefaultAsync(b =>
                    b.TableId == dto.TableId &&
                    b.BookingDate.Date == dto.BookingDate.Date &&
                    b.BookingTime == dto.BookingTime &&
                    b.Status != "Cancelled");

            if (existingBooking != null)
                return null;

            // Создаем бронирование
            var booking = new Booking
            {
                UserId = userId,
                TableId = dto.TableId,
                BookingDate = dto.BookingDate.Date,
                BookingTime = dto.BookingTime,
                GuestsCount = dto.GuestsCount,
                Status = "Pending",
                CreatedAt = DateTime.UtcNow
            };

            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();

            // Возвращаем результат
            return new BookingResponseDto
            {
                Id = booking.Id,
                TableId = booking.TableId,
                TableNumber = table.TableNumber,
                BookingDate = booking.BookingDate,
                BookingTime = booking.BookingTime,
                GuestsCount = booking.GuestsCount,
                Status = booking.Status,
                CreatedAt = booking.CreatedAt
            };
        }

        public async Task<List<BookingResponseDto>> GetUserBookingsAsync(int userId)
        {
            var bookings = await _context.Bookings
                .Include(b => b.Table)
                .Where(b => b.UserId == userId)
                .OrderByDescending(b => b.BookingDate)
                .ThenBy(b => b.BookingTime)
                .ToListAsync();

            var result = new List<BookingResponseDto>();

            foreach (var booking in bookings)
            {
                result.Add(new BookingResponseDto
                {
                    Id = booking.Id,
                    TableId = booking.TableId,
                    TableNumber = booking.Table?.TableNumber ?? 0,
                    BookingDate = booking.BookingDate,
                    BookingTime = booking.BookingTime,
                    GuestsCount = booking.GuestsCount,
                    Status = booking.Status,
                    CreatedAt = booking.CreatedAt
                });
            }

            return result;
        }

        public async Task<bool> CancelBookingAsync(int userId, int bookingId)
        {
            var booking = await _context.Bookings
                .FirstOrDefaultAsync(b => b.Id == bookingId && b.UserId == userId);

            if (booking == null)
                return false;

            if (booking.Status == "Cancelled")
                return false;

            booking.Status = "Cancelled";
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<Table>> GetAvailableTablesAsync(DateTime date, TimeSpan time, int guests)
        {
            // Получаем ID столов, которые уже забронированы
            var bookedTableIds = await _context.Bookings
                .Where(b => b.BookingDate.Date == date.Date &&
                            b.BookingTime == time &&
                            b.Status != "Cancelled")
                .Select(b => b.TableId)
                .ToListAsync();

            // Получаем свободные столы
            var availableTables = await _context.Tables
                .Where(t => t.Capacity >= guests && !bookedTableIds.Contains(t.Id))
                .ToListAsync();

            return availableTables;
        }
    }
}