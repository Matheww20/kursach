﻿using Microsoft.EntityFrameworkCore;
using CafeRestAPI.Models;
using CafeRestAPI.Models.DTOs;

namespace CafeRestAPI.Services
{
    public interface IOrderService
    {
        Task<OrderResponseDto?> CreateOrderAsync(int userId, CreateOrderDto dto);
        Task<List<OrderResponseDto>> GetUserOrdersAsync(int userId);
        Task<OrderResponseDto?> GetOrderByIdAsync(int userId, int orderId);
        Task<bool> CancelOrderAsync(int userId, int orderId);
    }

    public class OrderService : IOrderService
    {
        private readonly DbContextSalon _context;
        private readonly ICartService _cartService;

        public OrderService(DbContextSalon context, ICartService cartService)
        {
            _context = context;
            _cartService = cartService;
        }

        public async Task<OrderResponseDto?> CreateOrderAsync(int userId, CreateOrderDto dto)
        {
            var cart = await _context.Carts
                .Include(c => c.CartItems)
                    .ThenInclude(ci => ci.MenuItem)
                .FirstOrDefaultAsync(c => c.UserId == userId);

            if (cart == null || !cart.CartItems.Any())
                return null;

            var totalAmount = cart.CartItems.Sum(ci => ci.MenuItem.Price * ci.Quantity);
            var orderNumber = $"ORD-{userId}-{DateTime.Now:yyyyMMddHHmmss}";

            var order = new Order
            {
                UserId = userId,
                OrderNumber = orderNumber,
                TotalAmount = totalAmount,
                OrderType = dto.OrderType,
                DeliveryAddress = dto.DeliveryAddress,
                DeliveryPhone = dto.DeliveryPhone,
                Notes = dto.Notes,
                Status = "Pending",
                CreatedAt = DateTime.UtcNow
            };

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();

            foreach (var cartItem in cart.CartItems)
            {
                _context.OrderItems.Add(new OrderItem
                {
                    OrderId = order.Id,
                    MenuItemId = cartItem.MenuItemId,
                    Quantity = cartItem.Quantity,
                    Price = cartItem.MenuItem.Price,
                    Notes = cartItem.Notes
                });
            }

            await _context.SaveChangesAsync();
            await _cartService.ClearCartAsync(userId);

            return await GetOrderByIdAsync(userId, order.Id);
        }

        public async Task<List<OrderResponseDto>> GetUserOrdersAsync(int userId)
        {
            var orders = await _context.Orders
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.MenuItem)
                .Where(o => o.UserId == userId)
                .OrderByDescending(o => o.CreatedAt)
                .ToListAsync();

            return orders.Select(MapToDto).ToList();
        }

        public async Task<OrderResponseDto?> GetOrderByIdAsync(int userId, int orderId)
        {
            var order = await _context.Orders
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.MenuItem)
                .FirstOrDefaultAsync(o => o.Id == orderId && o.UserId == userId);

            return order == null ? null : MapToDto(order);
        }

        public async Task<bool> CancelOrderAsync(int userId, int orderId)
        {
            var order = await _context.Orders
                .FirstOrDefaultAsync(o => o.Id == orderId && o.UserId == userId);

            if (order == null || order.Status == "Cancelled")
                return false;

            order.Status = "Cancelled";
            await _context.SaveChangesAsync();
            return true;
        }

        private OrderResponseDto MapToDto(Order order)
        {
            return new OrderResponseDto
            {
                Id = order.Id,
                OrderNumber = order.OrderNumber,
                TotalAmount = order.TotalAmount,
                Status = order.Status,
                OrderType = order.OrderType,
                CreatedAt = order.CreatedAt,
                Items = order.OrderItems.Select(oi => new OrderItemDto
                {
                    Name = oi.MenuItem?.Name ?? string.Empty,
                    Quantity = oi.Quantity,
                    Price = oi.Price,
                    Subtotal = oi.Price * oi.Quantity,
                    Notes = oi.Notes
                }).ToList()
            };
        }
    }
}