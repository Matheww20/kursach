﻿using System;
using System.Collections.Generic;

namespace CafeRestAPI.Models;

public partial class Order
{
    public int Id { get; set; }

    public int UserId { get; set; }

    public string OrderNumber { get; set; } = null!;

    public decimal TotalAmount { get; set; }

    public string Status { get; set; } = null!;

    public string OrderType { get; set; } = null!;

    public string? DeliveryAddress { get; set; }

    public string? DeliveryPhone { get; set; }

    public string? Notes { get; set; }

    public DateTime CreatedAt { get; set; }

    public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

    public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();

    public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();

    public virtual User User { get; set; } = null!;
}
