﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CafeRestAPI.Models
{
    [Table("Tables")]
    public partial class Table
    {
        [Key]
        public int Id { get; set; }

        public int TableNumber { get; set; }

        public int Capacity { get; set; }

        public bool IsAvailable { get; set; } = true;

        [InverseProperty("Table")]
        public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();
    }
}