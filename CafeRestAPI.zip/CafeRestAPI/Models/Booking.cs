﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CafeRestAPI.Models
{
    [Table("Bookings")]
    public partial class Booking
    {
        [Key]
        public int Id { get; set; }

        public int UserId { get; set; }

        public int TableId { get; set; }

        public DateTime BookingDate { get; set; }

        public TimeSpan BookingTime { get; set; }

        public int GuestsCount { get; set; }

        [StringLength(20)]
        public string Status { get; set; } = "Pending";

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [ForeignKey("UserId")]
        [InverseProperty("Bookings")]
        public virtual User? User { get; set; }

        [ForeignKey("TableId")]
        [InverseProperty("Bookings")]
        public virtual Table? Table { get; set; }
    }
}