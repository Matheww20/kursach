﻿using System.ComponentModel.DataAnnotations;

namespace CafeRestAPI.Models.DTOs
{
    public class CreateOrderDto
    {
        [Required]
        public string OrderType { get; set; } = string.Empty;

        public string? DeliveryAddress { get; set; }
        public string? DeliveryPhone { get; set; }
        public string? Notes { get; set; }
    }

    public class OrderResponseDto
    {
        public int Id { get; set; }
        public string OrderNumber { get; set; } = string.Empty;
        public decimal TotalAmount { get; set; }
        public string Status { get; set; } = string.Empty;
        public string OrderType { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public List<OrderItemDto> Items { get; set; } = new List<OrderItemDto>();
    }

    public class OrderItemDto
    {
        public string Name { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public decimal Subtotal { get; set; }
        public string? Notes { get; set; }
    }
}