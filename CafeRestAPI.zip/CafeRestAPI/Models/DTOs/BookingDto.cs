﻿using System.ComponentModel.DataAnnotations;

namespace CafeRestAPI.Models.DTOs
{
    public class CreateBookingDto
    {
        [Required(ErrorMessage = "ID стола обязателен")]
        public int TableId { get; set; }

        [Required(ErrorMessage = "Дата бронирования обязательна")]
        public DateTime BookingDate { get; set; }

        [Required(ErrorMessage = "Время бронирования обязательно")]
        public TimeSpan BookingTime { get; set; }

        [Required(ErrorMessage = "Количество гостей обязательно")]
        [Range(1, 20, ErrorMessage = "Количество гостей должно быть от 1 до 20")]
        public int GuestsCount { get; set; }
    }

    public class BookingResponseDto
    {
        public int Id { get; set; }
        public int TableId { get; set; }
        public int TableNumber { get; set; }
        public DateTime BookingDate { get; set; }
        public TimeSpan BookingTime { get; set; }
        public int GuestsCount { get; set; }
        public string Status { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
    }
}