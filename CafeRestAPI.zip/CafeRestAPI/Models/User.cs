﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CafeRestAPI.Models
{
    [Table("Users")]
    public partial class User
    {
        [Key]
        public int Id { get; set; }

        [StringLength(100)]
        public string Email { get; set; } = string.Empty;

        [StringLength(255)]
        public string PasswordHash { get; set; } = string.Empty;

        [StringLength(100)]
        public string FullName { get; set; } = string.Empty;

        [StringLength(20)]
        public string? Phone { get; set; }

        [StringLength(500)]
        public string? Address { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public bool IsActive { get; set; } = true;

        [InverseProperty("User")]
        public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();

        [InverseProperty("User")]
        public virtual ICollection<Order> Orders { get; set; } = new List<Order>();

        [InverseProperty("User")]
        public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();

        public virtual Cart? Cart { get; set; }
    }
}